import './sidebar.css'

function SideBar(){
    return(
        <div className="sidebar">
            <div className="options">
                <span>wishlist</span>
                <span>archive</span>
                <span>profile</span>
            </div>

        </div>
    );
}

export default SideBar;