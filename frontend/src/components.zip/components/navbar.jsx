import './navbar.css';

function NavBar(){

    return(
        <div className='Navbar'>
            <div className='navbar-items'>
            <span>Teleported</span>
            <input type='search' placeholder='Wheres your dream vacations?' size={30}></input>
            <div className='navbar-items-right'>

            </div>
            </div>
        </div>
    );

}

export default NavBar